﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Make_Cube : MonoBehaviour {

    public List<GameObject> AllObjects = new List<GameObject>();
}
