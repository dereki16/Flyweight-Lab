﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Variables : MonoBehaviour {

    public int id;
    public int size;
    public int health;
    public int xp;
}
