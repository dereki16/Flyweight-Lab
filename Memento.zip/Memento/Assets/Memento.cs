﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Memento : MonoBehaviour {

    List<Object> Saving = new List<Object>();

    public class Object
    {
        public int id;
        public int size;
        public int health;
        public int xp;
        public Color col;
        public Vector3 Pos;
    }

    private void OnDestroy()
    {

        if (GetComponent<Make_Cube>().AllObjects.Count < 0)
        {
            List<GameObject> OldObjects = GetComponent<Make_Cube>().AllObjects;
            for (int ii = 0; ii < GetComponent<Make_Cube>().AllObjects.Count; ii++)
            {
                Object holding = new Object();
                holding.id = OldObjects[ii].GetComponent<Variables>().id;
                holding.Pos = OldObjects[ii].transform.position;
                holding.health = OldObjects[ii].GetComponent<Variables>().health;
                holding.xp = OldObjects[ii].GetComponent<Variables>().xp;
                holding.size = OldObjects[ii].GetComponent<Variables>().size;
                holding.col = OldObjects[ii].GetComponent<Renderer>().sharedMaterial.color;
                Saving.Add(holding);
            }
        }
    }
}
