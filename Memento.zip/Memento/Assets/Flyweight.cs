﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flyweight : MonoBehaviour {
    public List<GameObject> gamestuff;
    public GameObject mesh;

    class DragonStats
    {
        GameObject Dragon;
        int health;
        int size;
        Color color;
        int xp;
    }

    Vector3 CreatePos()
    {
        Vector3 Pos;
        Pos.x = Random.Range(transform.position.x - 50, transform.position.x + 50);
        Pos.y = transform.position.y;
        Pos.z = Random.Range(transform.position.z - 50, transform.position.z + 50);
        return Pos;
    }

    // Create health of dragon
    int SetHealth()
    {
        return Random.Range(100, 9999999);
    }

    int SetSize(int health, int xp)
    {
        return (int)Mathf.Sqrt(xp / health);
    }

    int SetXP()
    {
        return Random.Range(100, 9999999);
    }

    Color SetColor()
    {
        return Random.ColorHSV(0f, 1f, 1f, 1f, 0.5f, 1);
    }

    // Flyweight area
    void Start ()
    {
        // check if any memento exists
        if (gamestuff.Count == 0)
        {
            // create flyweight stuff here
            for (int ii = 0; ii < 100; ii++)
            {
                GameObject spawn = mesh;
                spawn.transform.position = CreatePos();
                spawn.GetComponent<Variables>().health = SetHealth();
                spawn.GetComponent<Variables>().xp = SetXP();
                spawn.GetComponent<Variables>().size = SetSize(spawn.GetComponent<Variables>().health, spawn.GetComponent<Variables>().health = SetXP());
                spawn.GetComponent<Renderer>().sharedMaterial.color = SetColor();

                Instantiate(spawn);
                gamestuff.Add(spawn);
            }
        }
        else
        {

        }
		
	}
	
	
}
